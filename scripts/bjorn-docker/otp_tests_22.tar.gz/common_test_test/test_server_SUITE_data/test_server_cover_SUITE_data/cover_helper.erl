-module(cover_helper).
-compile(export_all).
foo() -> ok.
bar() -> ok.
