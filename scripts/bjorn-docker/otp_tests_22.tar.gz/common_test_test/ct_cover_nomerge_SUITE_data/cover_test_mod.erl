-module(cover_test_mod).
-compile(export_all).
foo() ->
    ok.
